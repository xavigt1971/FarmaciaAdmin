package com.example.myappbdsw;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONObject;


public class EliminarActivity extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {
    private EditText idTxt;
    private TextView nombreTxt, cantidadTxt, precioTxt, fechaTxt;
    private String  nombre, cantidad, precio, fecha;
    private RequestQueue requestQueue;
    private JsonObjectRequest jsonObjectRequest;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar);
        idTxt = findViewById(R.id.txtID);
        nombreTxt=findViewById(R.id.txtNombre);
        cantidadTxt=findViewById(R.id.txtCantidad);
        precioTxt=findViewById(R.id.txtPrecio);
        fechaTxt=findViewById(R.id.txtFecha);

        requestQueue = Volley.newRequestQueue(this);

    }

    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.btnBuscar:
                this.buscarPorID();
                break;
            case R.id.btnEliminarDato:
                this.eliminarDato();
                break;

        }

    }

  public void buscarPorID(){


       if(!idTxt.getText().toString().isEmpty()) {
           try{
               String url;
               url = InsertarActivity.IP_SERVER + "/php_sw/buscar.php?id_medicamento=" + idTxt.getText().toString();
               jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
               requestQueue.add(jsonObjectRequest);

           }
           catch (Exception e){
               Toast.makeText(this, "Dato no existe en la base de datos", Toast.LENGTH_SHORT).show();

           }

       }else{

           Toast.makeText(this, "Falta ID", Toast.LENGTH_SHORT).show();

       }

  }

  public void eliminarDato(){

      if(!idTxt.getText().toString().isEmpty()) {
          String url;
          url = InsertarActivity.IP_SERVER + "/php_sw/eliminar.php?id_medicamento=" + idTxt.getText().toString();
          StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
              @Override
              public void onResponse(String response) {
                  Toast.makeText(EliminarActivity.this, "Datos Eliminados", Toast.LENGTH_SHORT).show();
              }
          },
                  new Response.ErrorListener() {
                      @Override
                      public void onErrorResponse(VolleyError error) {
                          if (error instanceof TimeoutError) {
                              Toast.makeText(EliminarActivity.this, "error_network_timeout", Toast.LENGTH_SHORT).show();
                          } else if (error instanceof ServerError) {
                              Toast.makeText(EliminarActivity.this, "error_server", Toast.LENGTH_SHORT).show();
                          } else if (error instanceof NetworkError) {
                              Toast.makeText(EliminarActivity.this, "network error", Toast.LENGTH_SHORT).show();
                          } else if (error instanceof ParseError) {
                              Toast.makeText(EliminarActivity.this, "parse error", Toast.LENGTH_SHORT).show();
                          } else {
                              Toast.makeText(EliminarActivity.this, "algun otro error", Toast.LENGTH_SHORT).show();
                          }

                      }

      });
          requestQueue.add(stringRequest);
      }else{

          Toast.makeText(this, "Falta ingresar ID", Toast.LENGTH_SHORT).show();

      }

  }


    @Override
    public void onErrorResponse(VolleyError error) {
        if (error instanceof TimeoutError) {
            Toast.makeText(EliminarActivity.this, "error_network_timeout", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ServerError) {
            Toast.makeText(EliminarActivity.this, "error_server", Toast.LENGTH_SHORT).show();
        } else if (error instanceof NetworkError) {
            Toast.makeText(EliminarActivity.this, "network error", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ParseError) {
            Toast.makeText(EliminarActivity.this, "parse error", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(EliminarActivity.this, "algun otro error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResponse(JSONObject response) {


            //Obtencion de la respuesta de los registros obtenidos por la consulta de PHP
            JSONArray jsonArray = response.optJSONArray("medicamentos");

            try {

                //se define para poder cargar la informacion ya en el arreglo de respuesta
                JSONObject jsonObject = null;
                //se le asigna cada informacion por recorrido
                jsonObject = jsonArray.getJSONObject(0);

                //se agrega cada registro relacionado a los campos

                nombre = jsonObject.optString("nombre_medicamento");
                cantidad = String.valueOf(jsonObject.optInt("cantidad"));
                precio = String.valueOf(jsonObject.optInt("precio"));
                fecha = (jsonObject.optString("fecha_vencimiento"));
                nombreTxt.setText(nombre);
                cantidadTxt.setText(cantidad);
                precioTxt.setText(precio);
                fechaTxt.setText(fecha);


            } catch (Exception e) {
                Toast.makeText(this, "" + e, Toast.LENGTH_SHORT).show();

            }

    }
}

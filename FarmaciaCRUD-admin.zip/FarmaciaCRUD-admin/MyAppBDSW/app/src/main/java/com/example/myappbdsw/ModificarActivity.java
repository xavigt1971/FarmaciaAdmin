package com.example.myappbdsw;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

public class ModificarActivity extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener  {
    private EditText idTxt;
    private TextView nombreTxt, cantidadTxt, precioTxt, fechaTxt;
    private String  nombre, cantidad, precio, fecha;
    private RequestQueue requestQueue;
    private JsonObjectRequest jsonObjectRequest;
    public final Calendar c = Calendar.getInstance();
    final int mes = c.get(Calendar.MONTH);
    final int dia = c.get(Calendar.DAY_OF_MONTH);
    final int anio = c.get(Calendar.YEAR);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);

        idTxt = findViewById(R.id.txtID);
        nombreTxt=findViewById(R.id.txtNombre);
        cantidadTxt=findViewById(R.id.txtCantidad);
        precioTxt=findViewById(R.id.txtPrecio);
        fechaTxt=findViewById(R.id.txtFecha);

        requestQueue = Volley.newRequestQueue(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.btnBuscar:
                this.buscarPorID();
                break;
            case R.id.btnActualizarDatos:
                this.actualizarDato();
                break;
            case R.id.imgFecha:

                fechaCalendario();
                break;

        }
    }


    public void buscarPorID(){


        if(!idTxt.getText().toString().isEmpty()) {
            try{
                String url;
                url = InsertarActivity.IP_SERVER + "/php_sw/buscar.php?id_medicamento=" + idTxt.getText().toString();
                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
                requestQueue.add(jsonObjectRequest);

            }
            catch (Exception e){
                Toast.makeText(this, "Dato no existe en la base de datos", Toast.LENGTH_SHORT).show();

            }

        }else{

            Toast.makeText(this, "Falta ID", Toast.LENGTH_SHORT).show();

        }

    }

    @Override
    public void onErrorResponse(VolleyError error) {
        if (error instanceof TimeoutError) {
          //  Toast.makeText(this, "error_network_timeout", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ServerError) {
        //    Toast.makeText(this, "error_server", Toast.LENGTH_SHORT).show();
        } else if (error instanceof NetworkError) {
        //    Toast.makeText(this, "network error", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ParseError) {
          //  Toast.makeText(this, "parse error", Toast.LENGTH_SHORT).show();
        } else {
          //  Toast.makeText(this, "algun otro error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResponse(JSONObject response) {

        //Obtencion de la respuesta de los registros obtenidos por la consulta de PHP
        JSONArray jsonArray = response.optJSONArray("medicamentos");

        try {

            //se define para poder cargar la informacion ya en el arreglo de respuesta
            JSONObject jsonObject = null;
            //se le asigna cada informacion por recorrido
            jsonObject = jsonArray.getJSONObject(0);

            //se agrega cada registro relacionado a los campos

            nombre = jsonObject.optString("nombre_medicamento");
            cantidad = String.valueOf(jsonObject.optInt("cantidad"));
            precio = String.valueOf(jsonObject.optInt("precio"));
            fecha = (jsonObject.optString("fecha_vencimiento"));
            nombreTxt.setText(nombre);
            cantidadTxt.setText(cantidad);
            precioTxt.setText(precio);
            fechaTxt.setText(fecha);


        } catch (Exception e) {
            Toast.makeText(this, "" + e, Toast.LENGTH_SHORT).show();

        }
    }

    public void actualizarDato(){

        if(!idTxt.getText().toString().isEmpty()) {
            String url;
            url = InsertarActivity.IP_SERVER + "/php_sw/actualizar.php?id_medicamento=" + idTxt.getText().toString()+
                                                "&nombre_medicamento="+nombreTxt.getText().toString()+
                                                "&cantidad="+cantidadTxt.getText().toString()+
                                                "&precio="+precioTxt.getText().toString()+
                                                "&fecha_vencimiento="+fechaTxt.getText().toString();
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Toast.makeText(ModificarActivity.this, "Datos actualizados", Toast.LENGTH_SHORT).show();
                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            if (error instanceof TimeoutError) {
                                Toast.makeText(ModificarActivity.this, "error_network_timeout", Toast.LENGTH_SHORT).show();
                            } else if (error instanceof ServerError) {
                                Toast.makeText(ModificarActivity.this, "error_server", Toast.LENGTH_SHORT).show();
                            } else if (error instanceof NetworkError) {
                                Toast.makeText(ModificarActivity.this, "network error", Toast.LENGTH_SHORT).show();
                            } else if (error instanceof ParseError) {
                                Toast.makeText(ModificarActivity.this, "parse error", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(ModificarActivity.this, "algun otro error", Toast.LENGTH_SHORT).show();
                            }

                        }

                    });
            requestQueue.add(stringRequest);
        }else{

            Toast.makeText(this, "Falta ingresar ID", Toast.LENGTH_SHORT).show();

        }

    }



    private void fechaCalendario() {
        DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                //Esta variable lo que realiza es aumentar en uno el mes ya que comienza desde 0 = enero
                final int mesActual = month + 1;
                //Formateo el día obtenido: antepone el 0 si son menores de 10
                String diaFormateado = (dayOfMonth < 10) ? 0 + String.valueOf(dayOfMonth) : String.valueOf(dayOfMonth);
                //Formateo el mes obtenido: antepone el 0 si son menores de 10
                String mesFormateado = (mesActual < 10) ? 0 + String.valueOf(mesActual) : String.valueOf(mesActual);

                String anio = String.valueOf(year);
                //Muestro la fecha con el formato deseado
                fechaTxt.setText(anio + "/" + mesFormateado + "/" + diaFormateado);



            }
            //Estos valores deben ir en ese orden, de lo contrario no mostrara la fecha actual
            /**
             *También puede cargar los valores que usted desee
             */
        }, anio, mes, dia);
        //Muestro el widget
        recogerFecha.show();

    }

}
